/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import flightBooking.Flight;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author HENRY
 */
public class FlightTest {
    
    public FlightTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void testConstructor(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 1000,800);
        assertEquals(p.toString(),"Flight 1, Toronto to New York, 08/08/08, original price:800.0$");
    }
    @Test(expected = IllegalArgumentException.class)
    public void invalidTestConstructor() throws IllegalArgumentException {
        Flight p = new Flight(1, "Toronto", "Toronto", "08/08/08", 1000,800);

    }
    @Test
    public void testBookASeat(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 0,800);
        assertEquals(p.bookASeat(),false);
    }
    @Test
    public void testFlightNumber(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 0,800);
        assertEquals(p.getFlightNumber(),1);
    }
    @Test
    public void testSetFlightNumber(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 0,800);
        Flight p1 = new Flight(12, "Toronto", "New York", "08/08/08", 0,800);
        p1.setFlightNumber(1);
        assertEquals(p.getFlightNumber(),p1.getFlightNumber());
    }
    @Test
    public void testOrigin(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 0,800);
        assertEquals(p.getOrigin(),"Toronto");
    }
    @Test
    public void testDestination(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 0,800);
        assertEquals(p.getDestination(),"New York");
    }
    @Test
    public void testDepartureTime(){
        Flight p = new Flight(1, "Toronto", "New York", "08/08/08", 0,800);
        assertEquals(p.getDepartureTime(),"08/08/08");
    }
}
